# Project Ouroborus is an artificial life environment built on a
# scheme of interchangeable open-source components.

# The code and ideas contained in this project have been contributed
# by the following people:

# Edgar Jose Becerra III
# Vian Patricio Gomez
# David Suarez
# Sat Tara Singh Khalsa

# Namo tantra tantrang.
# -Guru Gobind Singh, Jaap Sahib, 57
# I bow to that science which unites me to God.


# Here are the components which comprise the current version of ouroborus:

#   __init__.py     This file - duh!
#   birdcage.pyd    A library in C: the cellular automaton model
#   controller      Package - control routines
#   view            Package - display functionalities
#   docs            birdcage source file, plus documentation

# See the text files in the docs directory for more information
# or visit the project's website at http://ouroborus.sf.net



__name__ = 'ouroborus'
__version__ = '0.0.1'
__author__ = 'Edgar J Becerra III, Sat Tara S Khalsa <smonkey@entropia.com.mx>'
__copyright__ = 'Copyright 2006 (C) Project Ouroboros'
__license__ = 'GPL'
