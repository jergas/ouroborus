# Narayan is the background controller for all other processes;
# it coordinates the other classes which together comprise the
# controller component of Project Ouroborus

# At present, it only launches and reads the main dialogue

# It was written in Python 2.3.4 by Sat Tara Singh  
# Khalsa on December 16 2006, when it was found to run
# successfully on Windows XP, Deg Teg Fateh!


import ouroborus.controller.brahm
import ouroborus.controller.hare
import ouroborus.controller.ganesh 
import ouroborus.controller.dialogue as dial


class Narayan:
    """The Lord of the Universe, the Trascendent One"""

    def originateCosmos(self):
        """Primitive function: call the main dialogue

        return -->> None"""

        print "Prepare to originate cosmos..."
        self.brahm = ouroborus.controller.brahm.Brahm()
        print "brahm comes into existence"
        self.hare = ouroborus.controller.hare.Hare()
        print "hare comes into existence"
        self.ganesh = ouroborus.controller.ganesh.Ganesh()
        print "ganesh comes into existence"

        self.interpretMainDialogue()

    def interpretMainDialogue(self):
        """Accept user input from MainDialogue

        return -->> None"""
        
        user = dial.MainDialogue().cycle()

        if user == "creation":
            self.causeCreation()
            print "creation process finished...brahm enters contemplation"
            self.hare.brahm = self.brahm
            print "in fact, brahm becomes an attribute of hare"
            self.hare.chrono = 0
            self.causeSustainment()

        elif user == "retrieval":
            self.causeRetrieval()

        elif user == "exit":
            self.terminateCosmos()

    def causeCreation(self):
        """Order brahm to create a mundito

        return -->> None"""

        self.brahm.create()

    def causeSustainment(self):
        """Order hare to iterate a mundito

        return -->> None"""

        self.hare.status = "JUGJUGA"
        self.hare.sustain()

    def causeRetrieval(self):
        """Order ganesh to retrieve a mundito archive

        return -->> None"""

        self.ganesh.retrieve()

    def terminateCosmos(self):
        """End program

        return -->> None"""
        
        del self.brahm; print "brahm deleted"
        del self.ganesh; print "ganesh deleted"
        return


