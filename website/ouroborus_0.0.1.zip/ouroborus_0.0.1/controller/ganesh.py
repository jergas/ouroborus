import ouroborus.birdcage as ca


class Ganesh:

    def retrieve(self):
        print "retrieving"
        

        
