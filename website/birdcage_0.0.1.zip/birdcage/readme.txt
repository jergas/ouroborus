birdcage 0.3.1 with Pygame display

packaged on 4th October 2006

setup and exec instructions:


CONTENTS

This package includes the following componentes:

birdcage.pyd		The compiled birdcage library, version 0.3.1
__init__.py		Empty
parity.py		A test automaton with a Pygame display	
birdcage.pyx		The birdcage source code in Pyrex
setup_birdcage.py	The Python code used to compile birdcage

The requirements for running the test automaton, besides the birdcage library itself, are Python 2.x together with the Numeric, wxPython and Pygame libraries. They are accessible for download from the following URL's:

Python 2.x		http://www.python.org
Numeric			http://numpy.scipy.org
wxPython		http://www.wxpython.org
Pygame			http://www.pygame.org

If in addition you wish to have a go at the birdcage source code, the Pyrex extension language will also be needed. You may find it at http://www.cosc.canterbury.ac.nz/greg.ewing/python/Pyrex/


INSTALLATION

So far, birdcage has only been run on WindowsXP. Theoretically, it should work on UNIX platforms as well, but this hasn't been proven empirically yet. 

To install birdcage, simply copy the whole birdcage directory into the lib/site-packages/ directory of your Python installation


EXECUTION

The way to run the test automaton at this early stage of our
project is as follows:

1.- Invoke the Python command line - this can be done straight
from the Begin menu in WindowsXP. Of course, it's even easier on
a UNIX: simply type python in a shell.

2.- Type the following Python code:

	import birdcage.parity as p
	p.main((x,y),n,i)

where x and y are the dimensions of the grid (not to exceed 1000),
n is the number of cells initially alive and i is the number of
iterations you want to run through.

3.- When you're done use Ctrl-Z to exit the command line.

REMARKS

This early release is very likely crawling with bugs, so we'll
be grateful for any that you spot, and even more so for any that
you crush. Please send your comments to 

	smonkey@entropia.com.mx

So far, birdcage has only been tested on Python 2.3. Any info
on how birdcage runs on different platforms and versions of 
curses and Python will be appreciated.

Sat Tara Singh Khalsa
Project Ouroborus - ouroborus.sourceforge.net


