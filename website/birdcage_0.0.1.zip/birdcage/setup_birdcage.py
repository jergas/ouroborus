# Standard Pyrex 0.9.3 SetUp script for birdcage module
# Written in Python 2.3.4 


from distutils.core import setup
from distutils.extension import Extension
from Pyrex.Distutils import build_ext
setup(name='birdcage', ext_modules=[Extension("birdcage", ["birdcage.pyx"])],
cmdclass = {'build_ext': build_ext})
