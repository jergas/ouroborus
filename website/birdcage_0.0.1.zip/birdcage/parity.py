# This is a cellular automaton on a toroid topology with Von
# Neumann neighborhoods and a simple parity reduction rule, i.e.
# for each cell, if the number of live neighbours is even, the
# cell is dead (state 0), otherwise it is alive (state 1).

# This is a synchronous automaton which runs on the engine
# birdcage 0.3.1, and is part of Project Ouroboros.

# The visual display for this automaton uses the library Pygame.
# A key component of Pygame for our purposes is ehte module surfarray
# which requires the library Numeric in order to run properly.

# It was written in Python 2.3.4 by Sat Tara Singh Khalsa and
# written on November 26 2005, when it was found to run
# successfully on Windows XP, Deg Teg Fateh!


# import all necessary requirements

import birdcage as ca
import pygame as P
import Numeric as N
import pygame.surfarray as S
from pygame.locals import *
import operator



# some information regarding the cellular automaton

__name__ = "parity"
__author__ = "Sat Tara Singh Khalsa <smonkey@entropia.com.mx>"
__copyright__ = "Copyright (C) 2005 Project Ouroboros"
__license__ = "GPL"
__map__ = "Von Neumann (rectangular toroid, cardinal directions)"
__automaton__ = "Two-State Reduction"
__states__ = 2
__agents__ = 0
__rule__ = "Von Neumann Neighborhood Parity"
__visual__ = "Pygame"


# colors representing the automaton's states

black = 0
blue = 255


def buildAutomaton(size, seed=1):
    """Create a c.a. with the required specifications

    size     ---> grid dimensions, a 2-tuple
    seed     ---> cells originally alive, an integer
    return   -->> a birdcage automaton instance"""
    
    print "Preparing to build cellular automaton", __name__
    print "Commencing initialisation using the engine:",
    print ca.__name__, ca.__version__
    topology = ca.ToroidTopology(size,2,0)
    nsystem = ca.VonNeumannNeighborhood(topology,4)
    map = ca.Map(topology, nsystem)
    print "Map of size %d by %d created" % (size[1],size[0])
    print "Map style:", __map__
    function = operator.xor
    rule = ca.ReductionRule(map, function)
    automaton = ca.TwoStateReductionAutomaton(map, rule)
    print "Automaton rule selected and working copy prepared"
    print "Rule:",__rule__
    print "Automaton:",__automaton__
    ca.SeedInitializer(seed,1).py_initialize(automaton)
    print "%d initial cells animated" % seed
    print "The automaton is ready to run"
    return automaton


def createArray(size):
    """Create a Numeric array related to the c.a.

    size    ---> grid dimensions, a 2-tuple
    return  -->> a Numeric 2D array"""

    array = N.zeros(size)
    return array


def createDisplay(size):
    """Initialise pygame and create a pygame display

    size     ---> grid dimensions, a 2-tuple
    return   -->> a pygame screen"""

    screen = P.display.set_mode(size)
    P.init()
    P.display.set_caption("Parity")
    return screen
    

def updateArray(automaton, array, size):
    """update the Numeric array

    automaton ---> a birdcage automaton instance
    array     ---> a Numeric array of the same dimensions
    size      ---> a Python 2-tuple
    return    -->> None"""

    (width, height) = size
    for x in range(width):
        for y in range(height):
            if automaton.py_get2((x,y)) == 0:
                array[x,y] = black
            else:
                array[x,y] = blue


def refreshDisplay(screen, array):
    """Refresh the pygame display

    screen ---> a pygame screen object
    array  ---> a Numeric 2D array
    return -->> None"""

    S.blit_array(screen, array)
    P.display.flip()
    



def main(size, seed=0, iterate=10):
    """Run the main program sequence

    size    ---> a 2-tuple, the size of the c.a. grid
    seed    ---> an integer, number of cells originally alive
    iterate ---> an integer, the number of iterations to run through
    s       ---> sleep time in seconds"""

    automaton = buildAutomaton(size, seed)
    array = createArray(size)
    screen = createDisplay(size)
    
    refreshDisplay(screen,array)

    t = 0
    print "t = ", t
    
    for i in range(iterate):
        automaton.py_update()
        t = t+1
        updateArray(automaton, array, size)
        refreshDisplay(screen, array)
        print "t = ", t


    

if __name__ == '__main__': main((200,200),1,1000)


        
