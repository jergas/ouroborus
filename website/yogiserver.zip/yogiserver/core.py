# This module provides the core string functionality for Yogiserver
# Written on 19th May 2006 by Sat Tara Singh Khalsa. Deg Teh Fateh!
# The code was written on Python 2.3.4 and tested on Windows XP

import osfunc as o
import os
import pickle as p
import random as r


class Error(Exception):
    """Base class for exceptions in this module"""

    pass


class TypeError(Error):
    """Exception raised when the path fails"""

    def __init__(self, datum, message):
        """Create an instance of this error object
        datum   ---> the object which gave rise to the exception
        message ---> string, a message to be displayed"""
        self.datum = str(datum)
        self.message = message

    def __str__(self): 
        """Display a detailed error message
        return -->> a string with the excepted object and details"""
        s = "\'"+self.datum+"\' - "+self.message
        return s


class Yogi:
    """The class which integrates string handling functionalities"""

    def __init__(self, dir = os.curdir):
        """Set up a yogi instance together with working files"""
        self.adm = o.os_admin()
        self.dir = dir
        self.adm.make("mantras.yog", dir)
        self.adm.make("teachings.yog", dir)
        self.mantras = []
        self.teachings = []

    def make(self, workfile, dir = os.curdir):
        """Make an additional working file"""
        self.adm.make(workfile, dir)

    def cleanup(self):
        """Delete working files associated to this yogi"""
        self.adm.remove("mantras.yog", self.dir)
        self.adm.remove("teachings.yog", self.dir)

    def remove(self, file, dir = os.curdir):
        """Remove a file"""
        self.adm.remove(file, dir)

    def book(self, flag):
        """Identify action corresponding to flag"""
        if not type(flag) == type("string"):
            raise TypeError, "A string was expected"
        if flag == "mantra":
            return (self.mantras, "mantras.yog")
        elif flag == "teaching":
            return (self.teachings, "teachings.yog")
        else:
            raise ValueError, "Unknown flag passed"

    def add(self, flag, thing):
        if not type(thing) == type("string"):
            raise TypeError, (thing, "Yogi expected a string")
        elif len(thing) == 0:
            raise TypeError, (thing, "Yogi expected a non-empty string")
        else:
            self.book(flag)[0].append(thing)

    def list(self, flag):
        return self.book(flag)[0]

    def count(self, flag):
        return len(self.book(flag)[0])

    def pick(self, flag):
        if not self.count(flag) == 0:
            return self.book(flag)[0][r.randint(0,self.count(flag)-1)]
        else:
            raise ValueError, "no values to pick from"

    def read(self, flag, index):
        return self.book(flag)[0][index]

    def delete(self, flag, index):
        self.book(flag)[0].pop(index)

    def save(self, flag, workfile = "rump", dir = os.curdir):
        if workfile == "rump":
            workfile = self.book(flag)[1]
        file = self.adm.open(workfile, "w", dir)
        p.dump(self.book(flag)[0], file, p.HIGHEST_PROTOCOL)
        file.close()
        print "closing file"
        
    def load(self, flag, workfile = "rump", dir = os.curdir):
        if workfile == "rump":
            workfile = self.book(flag)[1]
        file = self.adm.open(workfile, "r")
        goods = p.load(file)
        if flag == "mantra": self.mantras = goods
        if flag == "teaching": self.teachings = goods
        file.close()
        print "closing file"

