# Here are some os functionalities intended for use with Yogiserver
# Written on 18th May 2006 by Sat Tara Singh Khalsa. Deg Teh Fateh!
# The code was written on Python 2.3.4 and tested on Windows XP

import os


class Error(Exception):
    """Base class for exceptions in this module"""

    pass


class PathError(Error):
    """Exception raised when the path fails"""

    def __init__(self, path, message):
        """Create an instance of this error object
        path    ---> string, the path associated to the error
        message ---> string, a message to be displayed"""
        self.path = path
        self.message = message

    def __str__(self): 
        """Display a detailed error message
        return -->> a string with the error's associated path and details"""
        s = "\'"+self.path+"\' - "+self.message
        return s


class os_admin:
    """This is the basic os handler class"""

    def dir_exist(self, dirname):
        """Verify that a directory exists
        dirname ---> string, the absolute or relative path to the directory
        return  -->> boolean, True if it exists"""
        if os.access(dirname, os.F_OK):
            return True
        else:
            return False
            
    def exist(self, filename, dirname = os.curdir):
        """Verify that a file exists
        filename ---> string, the name of a file
        dirname  ---> the path of the directory where the file may exist
        return   -->> boolean, True if it exists"""
        files = os.listdir(dirname)
        for i in range(len(files)):
            if filename == files[i]:
                return True
        return False

    def permission(self, path):
        """Verify user has permission to write on a directory or file
        path   ---> string, the path to the directory or file
        return -->> boolean, True if permission is obtained"""
        if os.access(path,os.W_OK):
            return True
        else:
            return False

    def make(self, filename, dirname = os.curdir):
        """Create a working file for use by the server
        filename ---> string, the name for the working file
        dirname  ---> string, the directory where the file will be built
        return   -->> None"""

        print "Checking directory pathname validity and permissions"

        absname = os.path.abspath(dirname)
        
        if self.permission(absname):
            print "ok\n"
            fullname = os.path.join(absname,filename)
        else:
            if self.dir_exist(absname):
                raise PathError, (dirname,"You don't have permission to write on this directory")
            else:
                raise PathError, (dirname, "This is not a valid directory")

        print "Creating working file", filename
        if self.exist(filename):
            raise PathError, (filename, "File already exists")
        try:
            filedescriptor = os.open(fullname,os.O_CREAT)
            os.close(filedescriptor)
            print "ok\n"
        except OSError:
            raise PathError, (filename, "Invalid file name")

    def open(self, filename, mode, dirname = os.curdir):
        """Return a write-open file object for pickling
        filename ---> string, the file to be opened
        mode     ---> string, 'w' to write and 'r' to read
        dirname  ---> string, the directory where the file lies
        return   -->> an open file Python object"""
        print "Opening file", filename
        absname = os.path.abspath(os.path.join(dirname, filename))
        if self.permission(absname):
            try:
                file = open(absname, mode)
                return file
            except OSError:
                raise PathError, (filename, "Could not open file")
        elif self.exist(absname):
            raise PathError, (filename, "You don't have permission to write on this file")
        else:
            raise PathError, (filename, "File does not exist")

    def remove(self, filename, dirname = os.curdir):
        """Delete a file from the main directory of the server
        filename ---> string, the name of the file
        dirname  ---> string, the directory where the file lies
        return   -->> None"""
        print "Preparing to remove file", filename
        absname = os.path.abspath(os.path.join(dirname, filename))
        if self.permission(absname):
            try:
                os.remove(absname)
                print "ok\n"
            except OSError:
                raise PathError, (filename, "File could not be deleted")
        elif self.exist(filename):
            raise PathError, (filename, "You don't have permission to write on this file")
        else:
            raise PathError, (filename, "File does not exist")
            

        

        
        
        
        
