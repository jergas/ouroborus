### This is a XML-RPC server which provides Web Services for interested
### yogis across the WorldWideWeb. It basically hosts an interactive list
### of mantras, teachings, or whatever other string content you desire.
### It was written in Python 2.3.4 on 22nd April 2006 by Sat Tara Singh Khalsa.
### An improved version was written on 19th May 2006 and tested on FreeBSD.
### Deg Teh Fateh!

import SimpleXMLRPCServer
import yogi

print "attempting to start server"
YogiObject = yogi.Yogi()

try:
    YogiServer = SimpleXMLRPCServer.SimpleXMLRPCServer(("spacemonkey.info",8080))
except:
    print "unable to start server"

try:
    YogiServer.register_instance(YogiObject)
except:
    print "unable to register methods"

print "server listening on port 8080"
YogiServer.serve_forever()
